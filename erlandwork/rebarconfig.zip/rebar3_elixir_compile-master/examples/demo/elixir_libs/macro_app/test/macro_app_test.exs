defmodule MacroAppTest do
  use ExUnit.Case
  doctest MacroApp

  test "the truth" do
    assert 1 + 1 == 2
  end
end
