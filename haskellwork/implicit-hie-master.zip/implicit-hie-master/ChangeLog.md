# Changelog for implicit-hie

## Unreleased changes
